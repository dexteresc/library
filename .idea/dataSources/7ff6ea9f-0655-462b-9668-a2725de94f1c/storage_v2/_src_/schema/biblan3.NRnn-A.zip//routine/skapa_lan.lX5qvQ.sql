create
    definer = root@localhost procedure skapa_lan(IN p_kundID int, IN p_artikelID int)
begin
    insert into lan (kund_kundID, artikel_ID) value (p_kundID, p_artikelID);
end;


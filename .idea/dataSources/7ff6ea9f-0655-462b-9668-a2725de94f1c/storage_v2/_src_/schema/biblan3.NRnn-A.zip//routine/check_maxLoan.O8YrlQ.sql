create
    definer = root@localhost function check_maxLoan(p_kundID int) returns int
    return (
    select k.maxLan from kund
        join kundtyp k on k.kundtypID = kund.kundtyp_kundtypID
    where kundID = p_kundID
    );


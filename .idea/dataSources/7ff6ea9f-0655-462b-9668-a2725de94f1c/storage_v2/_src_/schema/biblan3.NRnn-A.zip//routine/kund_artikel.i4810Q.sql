create
    definer = root@localhost function kund_artikel(kundID int) returns int
    return (select count(*)
    from lan where kund_kundID = kundID and returnerad = 0);


create
    definer = root@localhost function aktiva_lan(kundID int) returns int
    return (select count(*)
    from lan where kund_kundID = kundID and returnerad = 0);


create definer = root@localhost trigger lanAvArtikel
    before insert
    on lan
    for each row
begin
    IF (((select antal from artikel where new.artikel_ID = artikel.artikelID) <= 0))then
        signal sqlstate '45000' set message_text = 'There is not enough articles in stock';
    elseif (aktiva_lan(new.kund_kundID) >= check_maxLoan(new.kund_kundID)) then
        signal sqlstate '45000' set message_text = 'You\'ve reached your maximum loan limit';
    ELSE
        update biblan3.artikel set antal = antal - 1 where artikelID = new.artikel_ID;
        set new.landatum = now(),
            new.returdatum = adddate(now(), interval 4 week ),
            new.returnerad = 0;
end if;
end;


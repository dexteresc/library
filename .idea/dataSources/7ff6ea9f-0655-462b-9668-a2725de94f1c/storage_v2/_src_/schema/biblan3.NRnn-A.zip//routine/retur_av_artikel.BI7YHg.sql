create
    definer = root@localhost procedure retur_av_artikel(IN kundID int, IN p_artikelID int)
begin
    update lan set returnerad = 1 where kund_kundID = kundID and artikel_ID = p_artikelID;
    update artikel set antal = antal + 1 where artikelID = p_artikelID;
end;

